V0.002 não usa os novos codigos de estrutura e calculo.
a interface grafica desta verção não esta em funcionamento, apenas abre mas não tem utilização.

