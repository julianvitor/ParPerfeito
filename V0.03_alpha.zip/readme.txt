this GI (tkinter) not runing, but algorithm its working.


U need 'dados.csv' to running this software.
